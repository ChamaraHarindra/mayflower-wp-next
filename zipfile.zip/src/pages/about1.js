import MainLayout from "../components/Layout/MainLayout/MainLayout";
import About from "../views/about/about";

MainLayout;
export default function AboutPage() {
  return (
    <MainLayout>
      <About />
    </MainLayout>
  );
}
