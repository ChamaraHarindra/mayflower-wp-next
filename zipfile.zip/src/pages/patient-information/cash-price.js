import CashPrice from "../../views/patient-information/cash-price/cash-price";
import MainLayout from "../../components/Layout/MainLayout/MainLayout";

export default function CashPricePage() {
  return (
    <MainLayout>
      <CashPrice />
    </MainLayout>
  );
}
