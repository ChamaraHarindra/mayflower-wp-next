import Faq from "../../views/patient-information/faqs/faqs";
import MainLayout from "../../components/Layout/MainLayout/MainLayout";
export default function FaqPage() {
  return (
    <MainLayout>
      <Faq />
    </MainLayout>
  );
}
