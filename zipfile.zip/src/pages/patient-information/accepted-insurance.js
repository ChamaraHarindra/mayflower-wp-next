import AcceptedInsurance from "../../views/patient-information/accepted-insurance/accepted-insurance";
import MainLayout from "../../components/Layout/MainLayout/MainLayout";
export default function AcceptedInsurancePage() {
  return (
    <MainLayout>
      <AcceptedInsurance />
    </MainLayout>
  );
}
