import WomenHealth from "../../views/services/women-health/women-health";
import MainLayout from "../../components/Layout/MainLayout/MainLayout";

export default function WomenHealthPage() {
  return (
    <MainLayout>
      <WomenHealth />
    </MainLayout>
  );
}
